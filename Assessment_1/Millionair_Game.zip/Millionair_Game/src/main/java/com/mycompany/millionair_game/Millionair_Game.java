package com.mycompany.millionair_game;

/**
 *
 * @author FabiF
 */
public class Millionair_Game {

    public static void main(String[] args) {
        GameStart gameStart = new GameStart();
        gameStart.start();
    }

}
